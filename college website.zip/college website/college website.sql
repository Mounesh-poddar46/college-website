-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 01, 2024 at 06:19 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `college website`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_commentmeta`
--

CREATE TABLE IF NOT EXISTS `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `wp_commentmeta`
--


-- --------------------------------------------------------

--
-- Table structure for table `wp_comments`
--

CREATE TABLE IF NOT EXISTS `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2024-05-29 12:33:37', '2024-05-29 12:33:37', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, '1', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_links`
--

CREATE TABLE IF NOT EXISTS `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `wp_links`
--


-- --------------------------------------------------------

--
-- Table structure for table `wp_options`
--

CREATE TABLE IF NOT EXISTS `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=194 ;

--
-- Dumping data for table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/college%20website/wordpress', 'yes'),
(2, 'home', 'http://localhost/college%20website/wordpress', 'yes'),
(3, 'blogname', 'Government Degree College Autonomous Kalaburagi', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'mouneshpoddar36@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/index.php/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:104:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:57:"index.php/category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:52:"index.php/category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:33:"index.php/category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:45:"index.php/category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:27:"index.php/category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:54:"index.php/tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:49:"index.php/tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:30:"index.php/tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:42:"index.php/tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:24:"index.php/tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:55:"index.php/type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:50:"index.php/type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:31:"index.php/type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:43:"index.php/type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:25:"index.php/type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:51:"index.php/easyimagesldr/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:61:"index.php/easyimagesldr/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:81:"index.php/easyimagesldr/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:76:"index.php/easyimagesldr/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:76:"index.php/easyimagesldr/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:57:"index.php/easyimagesldr/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:40:"index.php/easyimagesldr/([^/]+)/embed/?$";s:48:"index.php?easyimageslider=$matches[1]&embed=true";s:44:"index.php/easyimagesldr/([^/]+)/trackback/?$";s:42:"index.php?easyimageslider=$matches[1]&tb=1";s:52:"index.php/easyimagesldr/([^/]+)/page/?([0-9]{1,})/?$";s:55:"index.php?easyimageslider=$matches[1]&paged=$matches[2]";s:59:"index.php/easyimagesldr/([^/]+)/comment-page-([0-9]{1,})/?$";s:55:"index.php?easyimageslider=$matches[1]&cpage=$matches[2]";s:48:"index.php/easyimagesldr/([^/]+)(?:/([0-9]+))?/?$";s:54:"index.php?easyimageslider=$matches[1]&page=$matches[2]";s:40:"index.php/easyimagesldr/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:50:"index.php/easyimagesldr/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:70:"index.php/easyimagesldr/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"index.php/easyimagesldr/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"index.php/easyimagesldr/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:46:"index.php/easyimagesldr/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:42:"index.php/feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:37:"index.php/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:18:"index.php/embed/?$";s:21:"index.php?&embed=true";s:30:"index.php/page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:51:"index.php/comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:46:"index.php/comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:27:"index.php/comments/embed/?$";s:21:"index.php?&embed=true";s:54:"index.php/search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:49:"index.php/search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:30:"index.php/search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:42:"index.php/search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:24:"index.php/search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:57:"index.php/author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:52:"index.php/author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:33:"index.php/author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:45:"index.php/author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:27:"index.php/author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:79:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:74:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:55:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:67:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:49:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:66:"index.php/([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:61:"index.php/([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:42:"index.php/([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:54:"index.php/([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:36:"index.php/([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:53:"index.php/([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:48:"index.php/([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:29:"index.php/([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:41:"index.php/([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:23:"index.php/([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:68:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:78:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:98:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:93:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:93:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:74:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:63:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:67:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:87:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:82:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:75:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:82:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:71:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:57:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:67:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:87:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:82:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:82:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:63:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:74:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:61:"index.php/([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:48:"index.php/([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:37:"index.php/.?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:47:"index.php/.?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:67:"index.php/.?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"index.php/.?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"index.php/.?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:43:"index.php/.?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:26:"index.php/(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:30:"index.php/(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:50:"index.php/(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:45:"index.php/(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:38:"index.php/(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:45:"index.php/(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:34:"index.php/(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:3:{i:0;s:25:"add-to-any/add-to-any.php";i:1;s:47:"image-slider-widget/easy-slider-widget-lite.php";i:2;s:25:"insert-php/insert_php.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'twentyfourteen', 'yes'),
(41, 'stylesheet', 'twentyfourteen', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '37965', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'posts', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '0', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '37965', 'yes'),
(92, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(94, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'sidebars_widgets', 'a:5:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:2:{i:0;s:6:"meta-2";i:1;s:19:"a2a_follow_widget-2";}s:9:"sidebar-2";a:1:{i:0;s:13:"ewic-widget-2";}s:9:"sidebar-3";a:2:{i:0;s:19:"a2a_follow_widget-3";i:1;s:23:"a2a_share_save_widget-2";}s:13:"array_version";i:3;}', 'yes'),
(99, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(101, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'cron', 'a:5:{i:1717245221;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1717245237;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1717245379;a:1:{s:16:"ewic_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1717245387;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(107, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:2:{i:0;O:8:"stdClass":10:{s:8:"response";s:7:"upgrade";s:8:"download";s:58:"http://downloads.wordpress.org/release/wordpress-6.5.3.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:58:"http://downloads.wordpress.org/release/wordpress-6.5.3.zip";s:10:"no_content";s:69:"http://downloads.wordpress.org/release/wordpress-6.5.3-no-content.zip";s:11:"new_bundled";s:70:"http://downloads.wordpress.org/release/wordpress-6.5.3-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"6.5.3";s:7:"version";s:5:"6.5.3";s:11:"php_version";s:5:"7.0.0";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"6.4";s:15:"partial_version";s:0:"";}i:1;O:8:"stdClass":10:{s:8:"response";s:7:"upgrade";s:8:"download";s:59:"http://downloads.wordpress.org/release/wordpress-5.1.18.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"http://downloads.wordpress.org/release/wordpress-5.1.18.zip";s:10:"no_content";s:70:"http://downloads.wordpress.org/release/wordpress-5.1.18-no-content.zip";s:11:"new_bundled";s:71:"http://downloads.wordpress.org/release/wordpress-5.1.18-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:6:"5.1.18";s:7:"version";s:6:"5.1.18";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"6.4";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1717221466;s:15:"version_checked";s:5:"4.6.1";s:12:"translations";a:0:{}}', 'no'),
(111, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1717221467;s:7:"checked";a:3:{s:13:"twentyfifteen";s:3:"1.6";s:14:"twentyfourteen";s:3:"1.8";s:13:"twentysixteen";s:3:"1.3";}s:8:"response";a:3:{s:13:"twentyfifteen";a:6:{s:5:"theme";s:13:"twentyfifteen";s:11:"new_version";s:3:"3.7";s:3:"url";s:43:"https://wordpress.org/themes/twentyfifteen/";s:7:"package";s:58:"http://downloads.wordpress.org/theme/twentyfifteen.3.7.zip";s:8:"requires";s:3:"4.1";s:12:"requires_php";s:5:"5.2.4";}s:14:"twentyfourteen";a:6:{s:5:"theme";s:14:"twentyfourteen";s:11:"new_version";s:3:"3.9";s:3:"url";s:44:"https://wordpress.org/themes/twentyfourteen/";s:7:"package";s:59:"http://downloads.wordpress.org/theme/twentyfourteen.3.9.zip";s:8:"requires";s:3:"3.6";s:12:"requires_php";s:5:"5.2.4";}s:13:"twentysixteen";a:6:{s:5:"theme";s:13:"twentysixteen";s:11:"new_version";s:3:"3.2";s:3:"url";s:43:"https://wordpress.org/themes/twentysixteen/";s:7:"package";s:58:"http://downloads.wordpress.org/theme/twentysixteen.3.2.zip";s:8:"requires";s:3:"4.4";s:12:"requires_php";s:5:"5.2.4";}}s:12:"translations";a:0:{}}', 'no'),
(112, '_transient_random_seed', '7b0640e13a2e4e009f510cd22b5ddffb', 'yes'),
(118, 'can_compress_scripts', '1', 'no'),
(121, 'recently_activated', 'a:0:{}', 'yes'),
(124, 'ewic-settings-automatic_update', 'active', 'yes'),
(126, 'widget_ewic-widget', 'a:2:{i:2;a:1:{s:14:"ewic_shortcode";s:1:"9";}s:12:"_multiwidget";i:1;}', 'yes'),
(131, '_site_transient_timeout_wporg_theme_feature_list', '1716997038', 'no'),
(132, '_site_transient_wporg_theme_feature_list', 'a:0:{}', 'no'),
(133, 'theme_mods_twentysixteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1716986288;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(134, 'current_theme', 'Twenty Fourteen', 'yes'),
(135, 'theme_mods_twentyfifteen', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1716986329;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(136, 'theme_switched', '', 'yes'),
(138, '_transient_twentyfifteen_categories', '1', 'yes'),
(139, 'theme_mods_twentyfourteen', 'a:3:{i:0;b:0;s:12:"header_image";s:88:"http://localhost/college%20website/wordpress/wp-content/uploads/2024/05/cropped-gdc.jpeg";s:17:"header_image_data";O:8:"stdClass":5:{s:13:"attachment_id";i:8;s:3:"url";s:88:"http://localhost/college%20website/wordpress/wp-content/uploads/2024/05/cropped-gdc.jpeg";s:13:"thumbnail_url";s:88:"http://localhost/college%20website/wordpress/wp-content/uploads/2024/05/cropped-gdc.jpeg";s:6:"height";i:618;s:5:"width";i:1260;}}', 'yes'),
(140, 'widget_widget_twentyfourteen_ephemera', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(150, '_site_transient_timeout_browser_b9cbd8dc13f19f9e7eb854f472bfa274', '1717592246', 'no'),
(151, '_site_transient_browser_b9cbd8dc13f19f9e7eb854f472bfa274', 'a:10:{s:4:"name";s:6:"Chrome";s:7:"version";s:9:"109.0.0.0";s:8:"platform";s:7:"Windows";s:10:"update_url";s:29:"https://www.google.com/chrome";s:7:"img_src";s:43:"http://s.w.org/images/browsers/chrome.png?1";s:11:"img_src_ssl";s:44:"https://s.w.org/images/browsers/chrome.png?1";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;s:6:"mobile";b:0;}', 'no'),
(162, '_transient_is_multi_author', '0', 'yes'),
(166, '_transient_twentyfourteen_category_count', '1', 'yes'),
(177, 'widget_a2a_share_save_widget', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(178, 'widget_a2a_follow_widget', 'a:3:{i:2;a:18:{s:5:"title";s:0:"";s:11:"facebook_id";s:0:"";s:10:"twitter_id";s:0:"";s:12:"instagram_id";s:0:"";s:12:"pinterest_id";s:0:"";s:10:"behance_id";s:0:"";s:9:"flickr_id";s:0:"";s:13:"foursquare_id";s:0:"";s:9:"github_id";s:0:"";s:14:"google_plus_id";s:0:"";s:11:"linkedin_id";s:0:"";s:19:"linkedin_company_id";s:0:"";s:11:"snapchat_id";s:0:"";s:9:"tumblr_id";s:0:"";s:8:"vimeo_id";s:0:"";s:10:"youtube_id";s:0:"";s:18:"youtube_channel_id";s:0:"";s:7:"feed_id";s:0:"";}i:3;a:18:{s:5:"title";s:0:"";s:11:"facebook_id";s:0:"";s:10:"twitter_id";s:0:"";s:12:"instagram_id";s:0:"";s:12:"pinterest_id";s:0:"";s:10:"behance_id";s:0:"";s:9:"flickr_id";s:0:"";s:13:"foursquare_id";s:0:"";s:9:"github_id";s:0:"";s:14:"google_plus_id";s:0:"";s:11:"linkedin_id";s:0:"";s:19:"linkedin_company_id";s:0:"";s:11:"snapchat_id";s:0:"";s:9:"tumblr_id";s:0:"";s:8:"vimeo_id";s:0:"";s:10:"youtube_id";s:0:"";s:18:"youtube_channel_id";s:0:"";s:7:"feed_id";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(179, '_site_transient_update_plugins', 'O:8:"stdClass":5:{s:12:"last_checked";i:1717221467;s:7:"checked";a:5:{s:25:"add-to-any/add-to-any.php";s:5:"1.7.2";s:19:"akismet/akismet.php";s:3:"3.2";s:9:"hello.php";s:3:"1.6";s:47:"image-slider-widget/easy-slider-widget-lite.php";s:6:"1.1.47";s:25:"insert-php/insert_php.php";s:3:"1.3";}s:8:"response";a:3:{s:25:"add-to-any/add-to-any.php";O:8:"stdClass":14:{s:2:"id";s:24:"w.org/plugins/add-to-any";s:4:"slug";s:10:"add-to-any";s:6:"plugin";s:25:"add-to-any/add-to-any.php";s:11:"new_version";s:6:"1.8.10";s:3:"url";s:41:"https://wordpress.org/plugins/add-to-any/";s:7:"package";s:59:"http://downloads.wordpress.org/plugin/add-to-any.1.8.10.zip";s:5:"icons";a:2:{s:2:"1x";s:54:"https://ps.w.org/add-to-any/assets/icon.svg?rev=972738";s:3:"svg";s:54:"https://ps.w.org/add-to-any/assets/icon.svg?rev=972738";}s:7:"banners";a:2:{s:2:"2x";s:66:"https://ps.w.org/add-to-any/assets/banner-1544x500.png?rev=2167358";s:2:"1x";s:65:"https://ps.w.org/add-to-any/assets/banner-772x250.png?rev=2167357";}s:11:"banners_rtl";a:0:{}s:8:"requires";s:3:"4.5";s:6:"tested";s:3:"6.6";s:12:"requires_php";s:3:"5.6";s:16:"requires_plugins";a:0:{}s:13:"compatibility";O:8:"stdClass":0:{}}s:9:"hello.php";O:8:"stdClass":14:{s:2:"id";s:25:"w.org/plugins/hello-dolly";s:4:"slug";s:11:"hello-dolly";s:6:"plugin";s:9:"hello.php";s:11:"new_version";s:5:"1.7.2";s:3:"url";s:42:"https://wordpress.org/plugins/hello-dolly/";s:7:"package";s:59:"http://downloads.wordpress.org/plugin/hello-dolly.1.7.3.zip";s:5:"icons";a:2:{s:2:"2x";s:64:"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=2052855";s:2:"1x";s:64:"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=2052855";}s:7:"banners";a:2:{s:2:"2x";s:67:"https://ps.w.org/hello-dolly/assets/banner-1544x500.jpg?rev=2645582";s:2:"1x";s:66:"https://ps.w.org/hello-dolly/assets/banner-772x250.jpg?rev=2052855";}s:11:"banners_rtl";a:0:{}s:8:"requires";s:3:"4.6";s:6:"tested";s:5:"6.4.4";s:12:"requires_php";b:0;s:16:"requires_plugins";a:0:{}s:13:"compatibility";O:8:"stdClass":0:{}}s:47:"image-slider-widget/easy-slider-widget-lite.php";O:8:"stdClass":15:{s:2:"id";s:33:"w.org/plugins/image-slider-widget";s:4:"slug";s:19:"image-slider-widget";s:6:"plugin";s:47:"image-slider-widget/easy-slider-widget-lite.php";s:11:"new_version";s:7:"1.1.127";s:3:"url";s:50:"https://wordpress.org/plugins/image-slider-widget/";s:7:"package";s:61:"http://downloads.wordpress.org/plugin/image-slider-widget.zip";s:5:"icons";a:2:{s:2:"2x";s:72:"https://ps.w.org/image-slider-widget/assets/icon-256x256.png?rev=1675940";s:2:"1x";s:72:"https://ps.w.org/image-slider-widget/assets/icon-128x128.png?rev=1131240";}s:7:"banners";a:1:{s:2:"1x";s:74:"https://ps.w.org/image-slider-widget/assets/banner-772x250.png?rev=1674939";}s:11:"banners_rtl";a:0:{}s:8:"requires";s:3:"3.5";s:6:"tested";s:5:"6.5.3";s:12:"requires_php";b:0;s:16:"requires_plugins";a:0:{}s:13:"compatibility";O:8:"stdClass":0:{}s:14:"upgrade_notice";s:55:"<p>IMPORTANT! SECURITY BUGS FIX, PLEASE UPDATE NOW!</p>";}}s:12:"translations";a:0:{}s:9:"no_update";a:2:{s:19:"akismet/akismet.php";O:8:"stdClass":14:{s:2:"id";s:21:"w.org/plugins/akismet";s:4:"slug";s:7:"akismet";s:6:"plugin";s:19:"akismet/akismet.php";s:11:"new_version";s:5:"5.3.2";s:3:"url";s:38:"https://wordpress.org/plugins/akismet/";s:7:"package";s:55:"http://downloads.wordpress.org/plugin/akismet.5.3.2.zip";s:5:"icons";a:2:{s:2:"2x";s:60:"https://ps.w.org/akismet/assets/icon-256x256.png?rev=2818463";s:2:"1x";s:60:"https://ps.w.org/akismet/assets/icon-128x128.png?rev=2818463";}s:7:"banners";a:2:{s:2:"2x";s:63:"https://ps.w.org/akismet/assets/banner-1544x500.png?rev=2900731";s:2:"1x";s:62:"https://ps.w.org/akismet/assets/banner-772x250.png?rev=2900731";}s:11:"banners_rtl";a:0:{}s:8:"requires";s:3:"5.8";s:6:"tested";s:5:"6.4.4";s:12:"requires_php";s:6:"5.6.20";s:16:"requires_plugins";a:0:{}s:13:"compatibility";a:0:{}}s:25:"insert-php/insert_php.php";O:8:"stdClass":14:{s:2:"id";s:24:"w.org/plugins/insert-php";s:4:"slug";s:10:"insert-php";s:6:"plugin";s:25:"insert-php/insert_php.php";s:11:"new_version";s:6:"2.4.10";s:3:"url";s:41:"https://wordpress.org/plugins/insert-php/";s:7:"package";s:52:"http://downloads.wordpress.org/plugin/insert-php.zip";s:5:"icons";a:2:{s:2:"2x";s:63:"https://ps.w.org/insert-php/assets/icon-256x256.png?rev=2553296";s:2:"1x";s:63:"https://ps.w.org/insert-php/assets/icon-128x128.png?rev=2553296";}s:7:"banners";a:2:{s:2:"2x";s:66:"https://ps.w.org/insert-php/assets/banner-1544x500.jpg?rev=2474791";s:2:"1x";s:65:"https://ps.w.org/insert-php/assets/banner-772x250.jpg?rev=2474791";}s:11:"banners_rtl";a:0:{}s:8:"requires";s:3:"4.8";s:6:"tested";s:5:"6.2.5";s:12:"requires_php";s:3:"7.0";s:16:"requires_plugins";a:0:{}s:13:"compatibility";a:0:{}}}}', 'no'),
(181, '_transient_featured_content_ids', 'a:0:{}', 'yes'),
(182, 'addtoany_options', 'a:31:{s:8:"position";s:6:"bottom";s:30:"display_in_posts_on_front_page";s:1:"1";s:33:"display_in_posts_on_archive_pages";s:1:"1";s:19:"display_in_excerpts";s:1:"1";s:16:"display_in_posts";s:1:"1";s:16:"display_in_pages";s:1:"1";s:22:"display_in_attachments";s:1:"1";s:15:"display_in_feed";s:1:"1";s:7:"onclick";s:2:"-1";s:9:"icon_size";s:2:"16";s:6:"button";s:17:"favicon.png|16|16";s:13:"button_custom";s:0:"";s:17:"button_show_count";s:2:"-1";s:6:"header";s:0:"";s:23:"additional_js_variables";s:0:"";s:14:"additional_css";s:0:"";s:12:"custom_icons";s:2:"-1";s:16:"custom_icons_url";s:1:"/";s:17:"custom_icons_type";s:3:"png";s:18:"custom_icons_width";s:0:"";s:19:"custom_icons_height";s:0:"";s:10:"inline_css";s:1:"1";s:5:"cache";s:2:"-1";s:11:"button_text";s:5:"Share";s:24:"special_facebook_options";a:1:{s:10:"show_count";s:2:"-1";}s:15:"active_services";a:3:{i:0;s:8:"facebook";i:1;s:7:"twitter";i:2;s:8:"whatsapp";}s:29:"special_facebook_like_options";a:1:{s:4:"verb";s:4:"like";}s:29:"special_twitter_tweet_options";a:1:{s:10:"show_count";s:2:"-1";}s:30:"special_google_plusone_options";a:1:{s:10:"show_count";s:2:"-1";}s:33:"special_google_plus_share_options";a:1:{s:10:"show_count";s:2:"-1";}s:29:"special_pinterest_pin_options";a:1:{s:10:"show_count";s:2:"-1";}}', 'yes'),
(187, '_transient_timeout_plugin_slugs', '1717236556', 'no'),
(188, '_transient_plugin_slugs', 'a:5:{i:0;s:25:"add-to-any/add-to-any.php";i:1;s:19:"akismet/akismet.php";i:2;s:9:"hello.php";i:3;s:47:"image-slider-widget/easy-slider-widget-lite.php";i:4;s:25:"insert-php/insert_php.php";}', 'no'),
(189, '_transient_timeout_dash_88ae138922fe95674369b1cb3d215a2b', '1717193356', 'no'),
(190, '_transient_dash_88ae138922fe95674369b1cb3d215a2b', '<div class="rss-widget"><p><strong>RSS Error</strong>: WP HTTP Error: stream_socket_client() [<a href=''function.stream-socket-client''>function.stream-socket-client</a>]: php_network_getaddresses: getaddrinfo failed: No such host is known. \nstream_socket_client() [<a href=''function.stream-socket-client''>function.stream-socket-client</a>]: unable to connect to tcp://wordpress.org:80 (php_network_getaddresses: getaddrinfo failed: No such host is known. )</p></div><div class="rss-widget"><p><strong>RSS Error</strong>: WP HTTP Error: No working transports found</p></div><div class="rss-widget"><ul></ul></div>', 'no'),
(192, '_site_transient_timeout_theme_roots', '1717223266', 'no'),
(193, '_site_transient_theme_roots', 'a:3:{s:13:"twentyfifteen";s:7:"/themes";s:14:"twentyfourteen";s:7:"/themes";s:13:"twentysixteen";s:7:"/themes";}', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `wp_postmeta`
--

CREATE TABLE IF NOT EXISTS `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=56 ;

--
-- Dumping data for table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(6, 7, '_wp_attached_file', '2024/05/gdc.jpeg'),
(7, 7, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1794;s:6:"height";i:881;s:4:"file";s:16:"2024/05/gdc.jpeg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"gdc-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:16:"gdc-300x147.jpeg";s:5:"width";i:300;s:6:"height";i:147;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:16:"gdc-768x377.jpeg";s:5:"width";i:768;s:6:"height";i:377;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:17:"gdc-1024x503.jpeg";s:5:"width";i:1024;s:6:"height";i:503;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:16:"gdc-672x372.jpeg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:17:"gdc-1038x576.jpeg";s:5:"width";i:1038;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(8, 8, '_wp_attached_file', '2024/05/cropped-gdc.jpeg'),
(9, 8, '_wp_attachment_context', 'custom-header'),
(10, 8, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1260;s:6:"height";i:618;s:4:"file";s:24:"2024/05/cropped-gdc.jpeg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"cropped-gdc-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"cropped-gdc-300x147.jpeg";s:5:"width";i:300;s:6:"height";i:147;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"cropped-gdc-768x377.jpeg";s:5:"width";i:768;s:6:"height";i:377;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"cropped-gdc-1024x502.jpeg";s:5:"width";i:1024;s:6:"height";i:502;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:24:"cropped-gdc-672x372.jpeg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:25:"cropped-gdc-1038x576.jpeg";s:5:"width";i:1038;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(11, 8, '_wp_attachment_custom_header_last_used_twentyfourteen', '1716986678'),
(12, 8, '_wp_attachment_is_custom_header', 'twentyfourteen'),
(13, 9, '_edit_last', '1'),
(14, 9, '_edit_lock', '1716987228:1'),
(15, 10, '_wp_attached_file', '2024/05/gdc2.jpg'),
(16, 10, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:254;s:6:"height";i:199;s:4:"file";s:16:"2024/05/gdc2.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"gdc2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(17, 11, '_wp_attached_file', '2024/05/gdc3.jpg'),
(18, 11, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:259;s:6:"height";i:194;s:4:"file";s:16:"2024/05/gdc3.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"gdc3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(19, 12, '_wp_attached_file', '2024/05/gdc4.jpg'),
(20, 12, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:329;s:6:"height";i:153;s:4:"file";s:16:"2024/05/gdc4.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"gdc4-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:16:"gdc4-300x140.jpg";s:5:"width";i:300;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(21, 13, '_wp_attached_file', '2024/05/gdc5.jpg'),
(22, 13, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:300;s:6:"height";i:168;s:4:"file";s:16:"2024/05/gdc5.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"gdc5-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:16:"gdc5-300x168.jpg";s:5:"width";i:300;s:6:"height";i:168;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(23, 14, '_wp_attached_file', '2024/05/gdc6.jpg'),
(24, 14, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:342;s:6:"height";i:147;s:4:"file";s:16:"2024/05/gdc6.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"gdc6-150x147.jpg";s:5:"width";i:150;s:6:"height";i:147;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:16:"gdc6-300x129.jpg";s:5:"width";i:300;s:6:"height";i:129;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(25, 9, 'ewic_meta_list_mode', ''),
(26, 9, 'ewic_meta_select_images', 'a:5:{i:10;a:2:{s:6:"images";s:2:"10";s:3:"ttl";s:4:"gdc2";}i:11;a:2:{s:6:"images";s:2:"11";s:3:"ttl";s:4:"gdc3";}i:14;a:2:{s:6:"images";s:2:"14";s:3:"ttl";s:4:"gdc6";}i:12;a:2:{s:6:"images";s:2:"12";s:3:"ttl";s:4:"gdc4";}i:13;a:2:{s:6:"images";s:2:"13";s:3:"ttl";s:4:"gdc5";}}'),
(27, 9, 'ewic_meta_thumbsizelt', 'a:2:{s:5:"width";s:4:"auto";s:6:"height";s:4:"auto";}'),
(28, 9, 'ewic_meta_slide_timthumb', 'off'),
(29, 9, 'ewic_meta_slide_auto', 'on'),
(30, 9, 'ewic_meta_slide_delay', '2'),
(31, 9, 'ewic_meta_settings_effect', 'easeInQuad'),
(32, 9, 'ewic_meta_slide_style', 'horizontal'),
(33, 9, 'ewic_meta_slide_nav', 'always'),
(34, 9, 'ewic_meta_slide_title', 'on'),
(35, 9, 'ewic_meta_settings_smartttl', 'off'),
(36, 9, 'ewic_meta_slide_lightbox', 'on'),
(37, 9, 'ewic_meta_slide_lightbox_autoslide', 'on'),
(38, 9, 'ewic_meta_slide_lightbox_delay', '5'),
(39, 2, '_edit_lock', '1716987739:1'),
(40, 2, '_edit_last', '1'),
(41, 1, '_edit_lock', '1717049248:1'),
(42, 1, '_edit_last', '1'),
(45, 19, '_edit_last', '1'),
(46, 19, '_edit_lock', '1716987954:1'),
(47, 19, '_wp_page_template', 'default'),
(48, 21, '_edit_last', '1'),
(49, 21, '_wp_page_template', 'default'),
(50, 21, '_edit_lock', '1716988055:1'),
(51, 23, '_edit_last', '1'),
(52, 23, '_edit_lock', '1716988469:1'),
(53, 24, '_wp_attached_file', '2024/05/lib.png'),
(54, 24, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:225;s:6:"height";i:225;s:4:"file";s:15:"2024/05/lib.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:15:"lib-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(55, 23, '_wp_page_template', 'default');

-- --------------------------------------------------------

--
-- Table structure for table `wp_posts`
--

CREATE TABLE IF NOT EXISTS `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2024-05-29 12:33:37', '2024-05-29 12:33:37', '<img class="alignnone size-full wp-image-10" src="http://localhost/college%20website/wordpress/wp-content/uploads/2024/05/gdc2.jpg" alt="gdc2" width="254" height="199" />', 'Welcome To Government Degree College Autonomous Kalaburagi 585105', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2024-05-29 12:59:30', '2024-05-29 12:59:30', '', 0, 'http://localhost/college%20website/wordpress/?p=1', 0, 'post', '', 1),
(2, 1, '2024-05-29 12:33:37', '2024-05-29 12:33:37', '<table class="wp-list-table widefat fixed striped posts">\r\n<tbody id="the-list">\r\n<tr id="post-9" class="iedit author-self level-0 post-9 type-easyimageslider status-publish hentry">\r\n<td class="ewic_sc column-ewic_sc" data-colname="Shortcode"><span class="ewic-scode-block">[espro-slider id=9]</span></td>\r\n</tr>\r\n</tbody>\r\n</table>', 'About', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2024-05-29 13:00:34', '2024-05-29 13:00:34', '', 0, 'http://localhost/college%20website/wordpress/?page_id=2', 0, 'page', '', 0),
(3, 1, '2024-05-29 12:33:57', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2024-05-29 12:33:57', '0000-00-00 00:00:00', '', 0, 'http://localhost/college%20website/wordpress/?p=3', 0, 'post', '', 0),
(5, 1, '2024-05-29 12:36:27', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2024-05-29 12:36:27', '0000-00-00 00:00:00', '', 0, 'http://localhost/college%20website/wordpress/?post_type=easyimageslider&p=5', 0, 'easyimageslider', '', 0),
(7, 1, '2024-05-29 12:43:30', '2024-05-29 12:43:30', '', 'gdc', '', 'inherit', 'open', 'closed', '', 'gdc', '', '', '2024-05-29 12:43:30', '2024-05-29 12:43:30', '', 0, 'http://localhost/college%20website/wordpress/wp-content/uploads/2024/05/gdc.jpeg', 0, 'attachment', 'image/jpeg', 0),
(8, 1, '2024-05-29 12:43:52', '2024-05-29 12:43:52', '', 'cropped-gdc.jpeg', '', 'inherit', 'open', 'closed', '', 'cropped-gdc-jpeg', '', '', '2024-05-29 12:43:52', '2024-05-29 12:43:52', '', 0, 'http://localhost/college%20website/wordpress/wp-content/uploads/2024/05/cropped-gdc.jpeg', 0, 'attachment', 'image/jpeg', 0),
(9, 1, '2024-05-29 12:53:46', '2024-05-29 12:53:46', '', 'Banner 1', '', 'publish', 'closed', 'closed', '', 'banner-1', '', '', '2024-05-29 12:53:46', '2024-05-29 12:53:46', '', 0, 'http://localhost/college%20website/wordpress/?post_type=easyimageslider&#038;p=9', 0, 'easyimageslider', '', 0),
(10, 1, '2024-05-29 12:51:20', '2024-05-29 12:51:20', '', 'gdc2', '', 'inherit', 'open', 'closed', '', 'gdc2', '', '', '2024-05-29 12:59:22', '2024-05-29 12:59:22', '', 1, 'http://localhost/college%20website/wordpress/wp-content/uploads/2024/05/gdc2.jpg', 0, 'attachment', 'image/jpeg', 0),
(11, 1, '2024-05-29 12:52:06', '2024-05-29 12:52:06', '', 'gdc3', '', 'inherit', 'open', 'closed', '', 'gdc3', '', '', '2024-05-29 12:52:06', '2024-05-29 12:52:06', '', 0, 'http://localhost/college%20website/wordpress/wp-content/uploads/2024/05/gdc3.jpg', 0, 'attachment', 'image/jpeg', 0),
(12, 1, '2024-05-29 12:52:08', '2024-05-29 12:52:08', '', 'gdc4', '', 'inherit', 'open', 'closed', '', 'gdc4', '', '', '2024-05-29 12:52:08', '2024-05-29 12:52:08', '', 0, 'http://localhost/college%20website/wordpress/wp-content/uploads/2024/05/gdc4.jpg', 0, 'attachment', 'image/jpeg', 0),
(13, 1, '2024-05-29 12:52:10', '2024-05-29 12:52:10', '', '', '', 'inherit', 'open', 'closed', '', 'gdc5', '', '', '2024-05-29 13:05:37', '2024-05-29 13:05:37', '', 19, 'http://localhost/college%20website/wordpress/wp-content/uploads/2024/05/gdc5.jpg', 0, 'attachment', 'image/jpeg', 0),
(14, 1, '2024-05-29 12:52:12', '2024-05-29 12:52:12', '', 'gdc6', '', 'inherit', 'open', 'closed', '', 'gdc6', '', '', '2024-05-29 12:52:12', '2024-05-29 12:52:12', '', 0, 'http://localhost/college%20website/wordpress/wp-content/uploads/2024/05/gdc6.jpg', 0, 'attachment', 'image/jpeg', 0),
(15, 1, '2024-05-29 12:54:40', '2024-05-29 12:54:40', '<table class="wp-list-table widefat fixed striped posts">\r\n<tbody id="the-list">\r\n<tr id="post-9" class="iedit author-self level-0 post-9 type-easyimageslider status-publish hentry">\r\n<td class="ewic_sc column-ewic_sc" data-colname="Shortcode"><span class="ewic-scode-block">[espro-slider id=9]</span></td>\r\n</tr>\r\n</tbody>\r\n</table>', 'Sample Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2024-05-29 12:54:40', '2024-05-29 12:54:40', '', 2, 'http://localhost/college%20website/wordpress/index.php/2024/05/29/2-revision-v1/', 0, 'revision', '', 0),
(16, 1, '2024-05-29 12:59:05', '2024-05-29 12:59:05', '', 'Welcome To Government Degree College Autonomous Kalaburagi 585105', '', 'inherit', 'closed', 'closed', '', '1-autosave-v1', '', '', '2024-05-29 12:59:05', '2024-05-29 12:59:05', '', 1, 'http://localhost/college%20website/wordpress/index.php/2024/05/29/1-autosave-v1/', 0, 'revision', '', 0),
(17, 1, '2024-05-29 12:59:30', '2024-05-29 12:59:30', '<img class="alignnone size-full wp-image-10" src="http://localhost/college%20website/wordpress/wp-content/uploads/2024/05/gdc2.jpg" alt="gdc2" width="254" height="199" />', 'Welcome To Government Degree College Autonomous Kalaburagi 585105', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2024-05-29 12:59:30', '2024-05-29 12:59:30', '', 1, 'http://localhost/college%20website/wordpress/index.php/2024/05/29/1-revision-v1/', 0, 'revision', '', 0),
(18, 1, '2024-05-29 13:00:34', '2024-05-29 13:00:34', '<table class="wp-list-table widefat fixed striped posts">\r\n<tbody id="the-list">\r\n<tr id="post-9" class="iedit author-self level-0 post-9 type-easyimageslider status-publish hentry">\r\n<td class="ewic_sc column-ewic_sc" data-colname="Shortcode"><span class="ewic-scode-block">[espro-slider id=9]</span></td>\r\n</tr>\r\n</tbody>\r\n</table>', 'About', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2024-05-29 13:00:34', '2024-05-29 13:00:34', '', 2, 'http://localhost/college%20website/wordpress/index.php/2024/05/29/2-revision-v1/', 0, 'revision', '', 0),
(19, 1, '2024-05-29 13:05:52', '2024-05-29 13:05:52', '<div class="b120">\r\n<div class="wikiContents _2d3b ca53 _5333 a78b    c225">\r\n<div>\r\n<div class="faq__according-wrapper">\r\n\r\n&nbsp;\r\n\r\n<img class="alignnone size-medium wp-image-13" src="http://localhost/college%20website/wordpress/wp-content/uploads/2024/05/gdc5-300x168.jpg" alt="" width="300" height="168" />\r\n\r\nEstablished in <b>1932</b>, <b>Government College, Kalaburagi</b> is a leading institute in higher education, located in Karnataka. Students can pursue their education from the institute in Degree courses including PG and UG programs. These programs are offered in full-time mode. The institute has a good reputation for courses such as B.A., B.B.M., B.Com, B.Sc., M.A., M.Com, M.Sc. Government College, Kalaburagi provides the opportunity to gain expertise through its trained and experienced faculty in the fields of Hindi, English, Mathematics, Physics, Zoology, Microbiology, Computer Science. The courses provided are in the stream of Accounting and Commerce, Business and Management Studies, Humanities and Social Sciences, Science. Government College, Kalaburagi have 1427 seats, and offers excellent infrastructure facilities.\r\n<table>\r\n<tbody>\r\n<tr>\r\n<th><span style="color: white;">Particulars</span></th>\r\n<th><span style="color: white;">Statistics</span></th>\r\n</tr>\r\n<tr>\r\n<td>Campus Location</td>\r\n<td>Karnataka</td>\r\n</tr>\r\n<tr>\r\n<td>Courses Offered</td>\r\n<td>PG and UG</td>\r\n</tr>\r\n<tr>\r\n<td>No. of Seats</td>\r\n<td>1427</td>\r\n</tr>\r\n<tr>\r\n<td>Median Salary</td>\r\n<td>INR 127,059</td>\r\n</tr>\r\n<tr>\r\n<td>Fees Range</td>\r\n<td>-</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</div>\r\n</div>\r\n<span class="_5ee4">Read less</span></div>\r\n</div>\r\n<div class="_75fd _829a">\r\n<table class="table d00e d8b0 b3f1">\r\n<tbody>\r\n<tr class="">\r\n<td class=""><span class="_98ab">Year of establishment</span></td>\r\n<td class=""><span class="bcb8">1932</span></td>\r\n</tr>\r\n<tr class="">\r\n<td class=""><span class="_98ab">Ownership</span></td>\r\n<td class=""><span class="bcb8">Public/Government</span></td>\r\n</tr>\r\n<tr class="">\r\n<td class=""><span class="_98ab">UGC Approved</span></td>\r\n<td class=""><span class="bcb8">no</span></td>\r\n</tr>\r\n<tr class="">\r\n<td class=""><span class="_98ab">AIU MemberShip</span></td>\r\n<td class=""><span class="bcb8">no</span></td>\r\n</tr>\r\n<tr class="">\r\n<td class=""><span class="_98ab">Institute of national importance</span></td>\r\n<td class=""><span class="bcb8">no</span></td>\r\n</tr>\r\n<tr class="">\r\n<td class=""><span class="_98ab">NAAC accreditation</span></td>\r\n<td class=""><span class="bcb8">Grade ''A''</span></td>\r\n</tr>\r\n<tr class="">\r\n<td class=""><span class="_98ab">Website</span></td>\r\n<td class=""><span class="bcb8"><span class="_6e3a"><span class="c221">Go to Website <img class="_773c _6e6d _9016" src="https://images.shiksha.ws/pwa/public/images/commonIcons/external-link.svg" alt="External Link Icon" /></span></span></span></td>\r\n</tr>\r\n<tr class="">\r\n<td class=""><span class="_98ab">Also Known As</span></td>\r\n<td class=""><span class="bcb8">GCAK</span></td>\r\n</tr>\r\n<tr class="">\r\n<td class=""><span class="_98ab">Accepted Exams</span></td>\r\n<td class="">\r\n<div class="knowledgeBoxExams">\r\n<div class="_5ffb">\r\n<div><span class="c229"><a class="_5ffb ripple dark" href="https://www.shiksha.com/boards/karnataka-2nd-puc-board">Karnataka 2nd PUC</a><a class="_5ffb ripple dark" href="https://www.shiksha.com/boards/cbse-12th-board">CBSE 12th</a></span></div>\r\n</div>\r\n</div></td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</div>', 'College Info', '', 'publish', 'closed', 'closed', '', 'college-info', '', '', '2024-05-29 13:05:52', '2024-05-29 13:05:52', '', 0, 'http://localhost/college%20website/wordpress/?page_id=19', 0, 'page', '', 0),
(20, 1, '2024-05-29 13:05:52', '2024-05-29 13:05:52', '<div class="b120">\r\n<div class="wikiContents _2d3b ca53 _5333 a78b    c225">\r\n<div>\r\n<div class="faq__according-wrapper">\r\n\r\n&nbsp;\r\n\r\n<img class="alignnone size-medium wp-image-13" src="http://localhost/college%20website/wordpress/wp-content/uploads/2024/05/gdc5-300x168.jpg" alt="" width="300" height="168" />\r\n\r\nEstablished in <b>1932</b>, <b>Government College, Kalaburagi</b> is a leading institute in higher education, located in Karnataka. Students can pursue their education from the institute in Degree courses including PG and UG programs. These programs are offered in full-time mode. The institute has a good reputation for courses such as B.A., B.B.M., B.Com, B.Sc., M.A., M.Com, M.Sc. Government College, Kalaburagi provides the opportunity to gain expertise through its trained and experienced faculty in the fields of Hindi, English, Mathematics, Physics, Zoology, Microbiology, Computer Science. The courses provided are in the stream of Accounting and Commerce, Business and Management Studies, Humanities and Social Sciences, Science. Government College, Kalaburagi have 1427 seats, and offers excellent infrastructure facilities.\r\n<table>\r\n<tbody>\r\n<tr>\r\n<th><span style="color: white;">Particulars</span></th>\r\n<th><span style="color: white;">Statistics</span></th>\r\n</tr>\r\n<tr>\r\n<td>Campus Location</td>\r\n<td>Karnataka</td>\r\n</tr>\r\n<tr>\r\n<td>Courses Offered</td>\r\n<td>PG and UG</td>\r\n</tr>\r\n<tr>\r\n<td>No. of Seats</td>\r\n<td>1427</td>\r\n</tr>\r\n<tr>\r\n<td>Median Salary</td>\r\n<td>INR 127,059</td>\r\n</tr>\r\n<tr>\r\n<td>Fees Range</td>\r\n<td>-</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</div>\r\n</div>\r\n<span class="_5ee4">Read less</span></div>\r\n</div>\r\n<div class="_75fd _829a">\r\n<table class="table d00e d8b0 b3f1">\r\n<tbody>\r\n<tr class="">\r\n<td class=""><span class="_98ab">Year of establishment</span></td>\r\n<td class=""><span class="bcb8">1932</span></td>\r\n</tr>\r\n<tr class="">\r\n<td class=""><span class="_98ab">Ownership</span></td>\r\n<td class=""><span class="bcb8">Public/Government</span></td>\r\n</tr>\r\n<tr class="">\r\n<td class=""><span class="_98ab">UGC Approved</span></td>\r\n<td class=""><span class="bcb8">no</span></td>\r\n</tr>\r\n<tr class="">\r\n<td class=""><span class="_98ab">AIU MemberShip</span></td>\r\n<td class=""><span class="bcb8">no</span></td>\r\n</tr>\r\n<tr class="">\r\n<td class=""><span class="_98ab">Institute of national importance</span></td>\r\n<td class=""><span class="bcb8">no</span></td>\r\n</tr>\r\n<tr class="">\r\n<td class=""><span class="_98ab">NAAC accreditation</span></td>\r\n<td class=""><span class="bcb8">Grade ''A''</span></td>\r\n</tr>\r\n<tr class="">\r\n<td class=""><span class="_98ab">Website</span></td>\r\n<td class=""><span class="bcb8"><span class="_6e3a"><span class="c221">Go to Website <img class="_773c _6e6d _9016" src="https://images.shiksha.ws/pwa/public/images/commonIcons/external-link.svg" alt="External Link Icon" /></span></span></span></td>\r\n</tr>\r\n<tr class="">\r\n<td class=""><span class="_98ab">Also Known As</span></td>\r\n<td class=""><span class="bcb8">GCAK</span></td>\r\n</tr>\r\n<tr class="">\r\n<td class=""><span class="_98ab">Accepted Exams</span></td>\r\n<td class="">\r\n<div class="knowledgeBoxExams">\r\n<div class="_5ffb">\r\n<div><span class="c229"><a class="_5ffb ripple dark" href="https://www.shiksha.com/boards/karnataka-2nd-puc-board">Karnataka 2nd PUC</a><a class="_5ffb ripple dark" href="https://www.shiksha.com/boards/cbse-12th-board">CBSE 12th</a></span></div>\r\n</div>\r\n</div></td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</div>', 'College Info', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2024-05-29 13:05:52', '2024-05-29 13:05:52', '', 19, 'http://localhost/college%20website/wordpress/index.php/2024/05/29/19-revision-v1/', 0, 'revision', '', 0),
(21, 1, '2024-05-29 13:07:33', '2024-05-29 13:07:33', '<div class="paper-card spacingVariation">\r\n<div id="acp_section_fees_and_eligibility" class="_8efd _57fd _757c _48ca expanded ">\r\n<div class="_1003  _58f5">\r\n<div class="_50f3 multipleTableContainer">\r\n<div>\r\n<table class="table _1708 d00e d8b0">\r\n<thead>\r\n<tr>\r\n<th class="fcc1">Courses</th>\r\n<th class="fcc1">Tuition Fees</th>\r\n<th class="fcc1">Eligibility</th>\r\n</tr>\r\n</thead>\r\n<tbody>\r\n<tr class="">\r\n<td class="">\r\n<div><a class="_69c7 ripple dark" href="https://www.shiksha.com/college/government-college-kalaburagi-karnataka-other-71081/courses/msc-bc">M.Sc.</a><span class="_037f">(5 courses)</span></div></td>\r\n<td class=""><span class="_0572">– / –</span></td>\r\n<td class="">\r\n<div class="_5ffb">\r\n<div>Graduation : 50 %</div>\r\n</div></td>\r\n</tr>\r\n<tr class="">\r\n<td class="">\r\n<div><a class="_69c7 ripple dark" href="https://www.shiksha.com/college/government-college-kalaburagi-karnataka-other-71081/courses/bsc-bc">B.Sc.</a><span class="_037f">(1 course)</span></div></td>\r\n<td class=""><span class="_0572">– / –</span></td>\r\n<td class="">\r\n<div class="_5ffb">\r\n<div>Exams : <span class="c229"><a class="_5ffb ripple dark" href="https://www.shiksha.com/boards/cbse-12th-board">CBSE 12th</a><a class="_5ffb ripple dark" href="https://www.shiksha.com/boards/karnataka-2nd-puc-board">Karnataka 2nd PUC</a></span></div>\r\n</div></td>\r\n</tr>\r\n<tr class="">\r\n<td class="">\r\n<div><a class="_69c7 ripple dark" href="https://www.shiksha.com/college/government-college-kalaburagi-karnataka-other-71081/courses/mcom-bc">M.Com</a><span class="_037f">(1 course)</span></div></td>\r\n<td class=""><span class="_0572">– / –</span></td>\r\n<td class="">\r\n<div class="_5ffb">\r\n<div>Graduation : 50 %</div>\r\n</div></td>\r\n</tr>\r\n<tr class="">\r\n<td class="">\r\n<div><a class="_69c7 ripple dark" href="https://www.shiksha.com/college/government-college-kalaburagi-karnataka-other-71081/courses/ma-bc">M.A.</a><span class="_037f">(7 courses)</span></div></td>\r\n<td class=""><span class="_0572">– / –</span></td>\r\n<td class="">\r\n<div class="_5ffb">\r\n<div>Graduation : 50 %</div>\r\n</div></td>\r\n</tr>\r\n<tr class="">\r\n<td class="">\r\n<div><a class="_69c7 ripple dark" href="https://www.shiksha.com/college/government-college-kalaburagi-karnataka-other-71081/courses/bcom-bc">B.Com</a><span class="_037f">(1 course)</span></div></td>\r\n<td class=""><span class="_0572">– / –</span></td>\r\n<td class="">\r\n<div class="_5ffb">\r\n<div>Exams : <span class="c229"><a class="_5ffb ripple dark" href="https://www.shiksha.com/boards/cbse-12th-board">CBSE 12th</a><a class="_5ffb ripple dark" href="https://www.shiksha.com/boards/karnataka-2nd-puc-board">Karnataka 2nd PUC</a></span></div>\r\n</div></td>\r\n</tr>\r\n<tr class="">\r\n<td class="">\r\n<div><a class="_69c7 ripple dark" href="https://www.shiksha.com/college/government-college-kalaburagi-karnataka-other-71081/courses/bbm-bc">B.B.M.</a><span class="_037f">(1 course)</span></div></td>\r\n<td class=""><span class="_0572">– / –</span></td>\r\n<td class="">\r\n<div class="_5ffb">\r\n<div>Exams : <span class="c229"><a class="_5ffb ripple dark" href="https://www.shiksha.com/boards/cbse-12th-board">CBSE 12th</a><a class="_5ffb ripple dark" href="https://www.shiksha.com/boards/karnataka-2nd-puc-board">Karnataka 2nd PUC</a></span></div>\r\n</div></td>\r\n</tr>\r\n<tr class="">\r\n<td class="">\r\n<div><a class="_69c7 ripple dark" href="https://www.shiksha.com/college/government-college-kalaburagi-karnataka-other-71081/courses/ba-bc">B.A.</a><span class="_037f">(1 course)</span></div></td>\r\n<td class=""><span class="_0572">– / –</span></td>\r\n<td class="">\r\n<div class="_5ffb">\r\n<div>Exams : <span class="c229"><a class="_5ffb ripple dark" href="https://www.shiksha.com/boards/cbse-12th-board">CBSE 12th</a><a class="_5ffb ripple dark" href="https://www.shiksha.com/boards/karnataka-2nd-puc-board">Karnataka 2nd PUC</a></span></div>\r\n</div></td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div id="acp-tuples" class="_9db534"></div>', 'Course & Fees 2024', '', 'publish', 'closed', 'closed', '', 'course-fees-2024', '', '', '2024-05-29 13:07:33', '2024-05-29 13:07:33', '', 0, 'http://localhost/college%20website/wordpress/?page_id=21', 0, 'page', '', 0),
(22, 1, '2024-05-29 13:07:33', '2024-05-29 13:07:33', '<div class="paper-card spacingVariation">\r\n<div id="acp_section_fees_and_eligibility" class="_8efd _57fd _757c _48ca expanded ">\r\n<div class="_1003  _58f5">\r\n<div class="_50f3 multipleTableContainer">\r\n<div>\r\n<table class="table _1708 d00e d8b0">\r\n<thead>\r\n<tr>\r\n<th class="fcc1">Courses</th>\r\n<th class="fcc1">Tuition Fees</th>\r\n<th class="fcc1">Eligibility</th>\r\n</tr>\r\n</thead>\r\n<tbody>\r\n<tr class="">\r\n<td class="">\r\n<div><a class="_69c7 ripple dark" href="https://www.shiksha.com/college/government-college-kalaburagi-karnataka-other-71081/courses/msc-bc">M.Sc.</a><span class="_037f">(5 courses)</span></div></td>\r\n<td class=""><span class="_0572">– / –</span></td>\r\n<td class="">\r\n<div class="_5ffb">\r\n<div>Graduation : 50 %</div>\r\n</div></td>\r\n</tr>\r\n<tr class="">\r\n<td class="">\r\n<div><a class="_69c7 ripple dark" href="https://www.shiksha.com/college/government-college-kalaburagi-karnataka-other-71081/courses/bsc-bc">B.Sc.</a><span class="_037f">(1 course)</span></div></td>\r\n<td class=""><span class="_0572">– / –</span></td>\r\n<td class="">\r\n<div class="_5ffb">\r\n<div>Exams : <span class="c229"><a class="_5ffb ripple dark" href="https://www.shiksha.com/boards/cbse-12th-board">CBSE 12th</a><a class="_5ffb ripple dark" href="https://www.shiksha.com/boards/karnataka-2nd-puc-board">Karnataka 2nd PUC</a></span></div>\r\n</div></td>\r\n</tr>\r\n<tr class="">\r\n<td class="">\r\n<div><a class="_69c7 ripple dark" href="https://www.shiksha.com/college/government-college-kalaburagi-karnataka-other-71081/courses/mcom-bc">M.Com</a><span class="_037f">(1 course)</span></div></td>\r\n<td class=""><span class="_0572">– / –</span></td>\r\n<td class="">\r\n<div class="_5ffb">\r\n<div>Graduation : 50 %</div>\r\n</div></td>\r\n</tr>\r\n<tr class="">\r\n<td class="">\r\n<div><a class="_69c7 ripple dark" href="https://www.shiksha.com/college/government-college-kalaburagi-karnataka-other-71081/courses/ma-bc">M.A.</a><span class="_037f">(7 courses)</span></div></td>\r\n<td class=""><span class="_0572">– / –</span></td>\r\n<td class="">\r\n<div class="_5ffb">\r\n<div>Graduation : 50 %</div>\r\n</div></td>\r\n</tr>\r\n<tr class="">\r\n<td class="">\r\n<div><a class="_69c7 ripple dark" href="https://www.shiksha.com/college/government-college-kalaburagi-karnataka-other-71081/courses/bcom-bc">B.Com</a><span class="_037f">(1 course)</span></div></td>\r\n<td class=""><span class="_0572">– / –</span></td>\r\n<td class="">\r\n<div class="_5ffb">\r\n<div>Exams : <span class="c229"><a class="_5ffb ripple dark" href="https://www.shiksha.com/boards/cbse-12th-board">CBSE 12th</a><a class="_5ffb ripple dark" href="https://www.shiksha.com/boards/karnataka-2nd-puc-board">Karnataka 2nd PUC</a></span></div>\r\n</div></td>\r\n</tr>\r\n<tr class="">\r\n<td class="">\r\n<div><a class="_69c7 ripple dark" href="https://www.shiksha.com/college/government-college-kalaburagi-karnataka-other-71081/courses/bbm-bc">B.B.M.</a><span class="_037f">(1 course)</span></div></td>\r\n<td class=""><span class="_0572">– / –</span></td>\r\n<td class="">\r\n<div class="_5ffb">\r\n<div>Exams : <span class="c229"><a class="_5ffb ripple dark" href="https://www.shiksha.com/boards/cbse-12th-board">CBSE 12th</a><a class="_5ffb ripple dark" href="https://www.shiksha.com/boards/karnataka-2nd-puc-board">Karnataka 2nd PUC</a></span></div>\r\n</div></td>\r\n</tr>\r\n<tr class="">\r\n<td class="">\r\n<div><a class="_69c7 ripple dark" href="https://www.shiksha.com/college/government-college-kalaburagi-karnataka-other-71081/courses/ba-bc">B.A.</a><span class="_037f">(1 course)</span></div></td>\r\n<td class=""><span class="_0572">– / –</span></td>\r\n<td class="">\r\n<div class="_5ffb">\r\n<div>Exams : <span class="c229"><a class="_5ffb ripple dark" href="https://www.shiksha.com/boards/cbse-12th-board">CBSE 12th</a><a class="_5ffb ripple dark" href="https://www.shiksha.com/boards/karnataka-2nd-puc-board">Karnataka 2nd PUC</a></span></div>\r\n</div></td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div id="acp-tuples" class="_9db534"></div>', 'Course & Fees 2024', '', 'inherit', 'closed', 'closed', '', '21-revision-v1', '', '', '2024-05-29 13:07:33', '2024-05-29 13:07:33', '', 21, 'http://localhost/college%20website/wordpress/index.php/2024/05/29/21-revision-v1/', 0, 'revision', '', 0),
(23, 1, '2024-05-29 13:12:14', '2024-05-29 13:12:14', '<section id="infrastructureSection" class="infrastructureSection">\r\n<div class="_container">\r\n<h2 class="tbSec2">Infrastructure/Facilities<i class="amanityIcons Library"><img class="alignnone size-full wp-image-24" src="http://localhost/college%20website/wordpress/wp-content/uploads/2024/05/lib.png" alt="lib" width="225" height="225" /> Institute has 1 well equipped library with 139566 books 33 Journals</i></h2>\r\n<h2 class="tbSec2"><strong>Library</strong></h2>\r\n<div class="_subcontainer">\r\n<div class="facilityBox">\r\n<ul class="infraDataList">\r\n 	<li>\r\n<div class="dtl">\r\n\r\nInstitute has 1 well equipped library with 139566 books 33 Journals\r\n<div class="childFaciltyBox"></div>\r\n</div></li>\r\n 	<li>\r\n<div class="icn"><i class="amanityIcons Labs"></i><strong>Labs</strong></div>\r\n<div class="dtl">\r\n\r\nInstitute provides 16 labs facilities for the students\r\n<div class="childFaciltyBox"></div>\r\n</div></li>\r\n 	<li class="wrapFlx">\r\n<div class="icn"><i class="amanityIcons Cafeteria"></i><strong>Cafeteria</strong></div>\r\n<div class="icn"><i class="amanityIcons Sports"></i><strong>Sports Complex</strong></div>\r\n<div class="icn"><i class="amanityIcons Gym"></i><strong>Gym</strong></div>\r\n<div class="icn"><i class="amanityIcons Wi-Fi"></i><strong>Wi-Fi Campus</strong></div>\r\n<div class="icn"><i class="amanityIcons Auditorium"></i><strong>Auditorium</strong></div></li>\r\n</ul>\r\n</div>\r\n</div>\r\n</div>\r\n</section>\r\n<div class="lhs-dfp"></div>\r\n<div></div>', 'Infrastructure', '', 'publish', 'closed', 'closed', '', 'infrastructure', '', '', '2024-05-29 13:14:26', '2024-05-29 13:14:26', '', 0, 'http://localhost/college%20website/wordpress/?page_id=23', 0, 'page', '', 0),
(24, 1, '2024-05-29 13:11:47', '2024-05-29 13:11:47', '', 'lib', '', 'inherit', 'open', 'closed', '', 'lib', '', '', '2024-05-29 13:11:47', '2024-05-29 13:11:47', '', 23, 'http://localhost/college%20website/wordpress/wp-content/uploads/2024/05/lib.png', 0, 'attachment', 'image/png', 0),
(25, 1, '2024-05-29 13:12:14', '2024-05-29 13:12:14', '<section id="infrastructureSection" class="infrastructureSection">\r\n<div class="_container">\r\n<h2 class="tbSec2">Infrastructure/Facilities</h2>\r\n<div class="_subcontainer">\r\n<div class="facilityBox">\r\n<ul class="infraDataList">\r\n 	<li>\r\n<div class="icn"><i class="amanityIcons Library"><img class="alignnone size-full wp-image-24" src="http://localhost/college%20website/wordpress/wp-content/uploads/2024/05/lib.png" alt="lib" width="225" height="225" /></i><strong>Library</strong></div>\r\n<div class="dtl">\r\n\r\nInstitute has 1 well equipped library with 139566 books 33 Journals\r\n<div class="childFaciltyBox"></div>\r\n</div></li>\r\n 	<li>\r\n<div class="icn"><i class="amanityIcons Labs"></i><strong>Labs</strong></div>\r\n<div class="dtl">\r\n\r\nInstitute provides 16 labs facilities for the students\r\n<div class="childFaciltyBox"></div>\r\n</div></li>\r\n 	<li class="wrapFlx">\r\n<div class="icn"><i class="amanityIcons Cafeteria"></i><strong>Cafeteria</strong></div>\r\n<div class="icn"><i class="amanityIcons Sports"></i><strong>Sports Complex</strong></div>\r\n<div class="icn"><i class="amanityIcons Gym"></i><strong>Gym</strong></div>\r\n<div class="icn"><i class="amanityIcons Wi-Fi"></i><strong>Wi-Fi Campus</strong></div>\r\n<div class="icn"><i class="amanityIcons Auditorium"></i><strong>Auditorium</strong></div></li>\r\n</ul>\r\n</div>\r\n</div>\r\n</div>\r\n</section>\r\n<div class="lhs-dfp"></div>\r\n<div></div>', 'Infrastructure', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2024-05-29 13:12:14', '2024-05-29 13:12:14', '', 23, 'http://localhost/college%20website/wordpress/index.php/2024/05/29/23-revision-v1/', 0, 'revision', '', 0),
(26, 1, '2024-05-29 13:14:20', '2024-05-29 13:14:20', '<section id="infrastructureSection" class="infrastructureSection">\n<div class="_container">\n<h2 class="tbSec2">Infrastructure/Facilities<i class="amanityIcons Library"><img class="alignnone size-full wp-image-24" src="http://localhost/college%20website/wordpress/wp-content/uploads/2024/05/lib.png" alt="lib" width="225" height="225" /> Institute has 1 well equipped library with 139566 books 33 Journals</i></h2>\n<h2 class="tbSec2"><strong>Library</strong></h2>\n<div class="_subcontainer">\n<div class="facilityBox">\n<ul class="infraDataList">\n 	<li>\n<div class="dtl">\n\nInstitute has 1 well equipped library with 139566 books 33 Journals\n<div class="childFaciltyBox"></div>\n</div></li>\n 	<li>\n<div class="icn"><i class="amanityIcons Labs"></i><strong>Labs</strong></div>\n<div class="dtl">\n\nInstitute provides 16 labs facilities for the students\n<div class="childFaciltyBox"></div>\n</div></li>\n 	<li class="wrapFlx">\n<div class="icn"><i class="amanityIcons Cafeteria"></i><strong>Cafeteria</strong></div>\n<div class="icn"><i class="amanityIcons Sports"></i><strong>Sports Complex</strong></div>\n<div class="icn"><i class="amanityIcons Gym"></i><strong>Gym</strong></div>\n<div class="icn"><i class="amanityIcons Wi-Fi"></i><strong>Wi-Fi Campus</strong></div>\n<div class="icn"><i class="amanityIcons Auditorium"></i><strong>Auditorium</strong></div></li>\n</ul>\n</div>\n</div>\n</div>\n</section>\n<div class="lhs-dfp"></div>\n<div></div>', 'Infrastructure', '', 'inherit', 'closed', 'closed', '', '23-autosave-v1', '', '', '2024-05-29 13:14:20', '2024-05-29 13:14:20', '', 23, 'http://localhost/college%20website/wordpress/index.php/2024/05/29/23-autosave-v1/', 0, 'revision', '', 0),
(27, 1, '2024-05-29 13:14:26', '2024-05-29 13:14:26', '<section id="infrastructureSection" class="infrastructureSection">\r\n<div class="_container">\r\n<h2 class="tbSec2">Infrastructure/Facilities<i class="amanityIcons Library"><img class="alignnone size-full wp-image-24" src="http://localhost/college%20website/wordpress/wp-content/uploads/2024/05/lib.png" alt="lib" width="225" height="225" /> Institute has 1 well equipped library with 139566 books 33 Journals</i></h2>\r\n<h2 class="tbSec2"><strong>Library</strong></h2>\r\n<div class="_subcontainer">\r\n<div class="facilityBox">\r\n<ul class="infraDataList">\r\n 	<li>\r\n<div class="dtl">\r\n\r\nInstitute has 1 well equipped library with 139566 books 33 Journals\r\n<div class="childFaciltyBox"></div>\r\n</div></li>\r\n 	<li>\r\n<div class="icn"><i class="amanityIcons Labs"></i><strong>Labs</strong></div>\r\n<div class="dtl">\r\n\r\nInstitute provides 16 labs facilities for the students\r\n<div class="childFaciltyBox"></div>\r\n</div></li>\r\n 	<li class="wrapFlx">\r\n<div class="icn"><i class="amanityIcons Cafeteria"></i><strong>Cafeteria</strong></div>\r\n<div class="icn"><i class="amanityIcons Sports"></i><strong>Sports Complex</strong></div>\r\n<div class="icn"><i class="amanityIcons Gym"></i><strong>Gym</strong></div>\r\n<div class="icn"><i class="amanityIcons Wi-Fi"></i><strong>Wi-Fi Campus</strong></div>\r\n<div class="icn"><i class="amanityIcons Auditorium"></i><strong>Auditorium</strong></div></li>\r\n</ul>\r\n</div>\r\n</div>\r\n</div>\r\n</section>\r\n<div class="lhs-dfp"></div>\r\n<div></div>', 'Infrastructure', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2024-05-29 13:14:26', '2024-05-29 13:14:26', '', 23, 'http://localhost/college%20website/wordpress/index.php/2024/05/29/23-revision-v1/', 0, 'revision', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_termmeta`
--

CREATE TABLE IF NOT EXISTS `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `wp_termmeta`
--


-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

CREATE TABLE IF NOT EXISTS `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--

CREATE TABLE IF NOT EXISTS `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--

CREATE TABLE IF NOT EXISTS `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

CREATE TABLE IF NOT EXISTS `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(11, 1, 'wp_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', 'addtoany_settings_pointer'),
(13, 1, 'show_welcome_panel', '1'),
(14, 1, 'session_tokens', 'a:3:{s:64:"95d2dd5e28ea77b44a6df2455bcd76279568bfc0f1f8c3ad109176c9a8dac5a4";a:4:{s:10:"expiration";i:1717158836;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36";s:5:"login";i:1716986036;}s:64:"87b422b04a9494631a23a2c7d80fe25d0a316d7a6e32dc87bd9a05e65226e69c";a:4:{s:10:"expiration";i:1717220822;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36";s:5:"login";i:1717048022;}s:64:"efffc36b2cf6f10368e8395adbdd087751ca79ba4a503703c7bbb5a20a6fb992";a:4:{s:10:"expiration";i:1717322949;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36";s:5:"login";i:1717150149;}}'),
(15, 1, 'wp_dashboard_quick_press_last_post_id', '3'),
(16, 1, 'wp_user-settings', 'libraryContent=browse'),
(17, 1, 'wp_user-settings-time', '1716986717'),
(18, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(19, 1, 'metaboxhidden_nav-menus', 'a:2:{i:0;s:12:"add-post_tag";i:1;s:15:"add-post_format";}');

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--

CREATE TABLE IF NOT EXISTS `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(255) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BzXb8fMBzgdjqRruLu/rpHxNquqWX./', 'admin', 'mouneshpoddar36@gmail.com', '', '2024-05-29 12:33:37', '', 0, 'admin');
